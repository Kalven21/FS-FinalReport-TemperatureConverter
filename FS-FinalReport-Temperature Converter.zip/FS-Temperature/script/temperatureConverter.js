function convertTemperatureRange(){
    var startValue = Number(prompt("Write a start value"));
    var endValue = Number(prompt("Write an end value"));
    let scale = prompt("And choose bewteen C or F");
    for(let i=startValue;i<=endValue;i++){
        if(scale == "C"||scale == "c"){
            let Fahrenheit = Number((i*9/5)+32);
            document.getElementById("answer").innerHTML+=`
            <p>The conversation of Celcius ${i} to Fahrenheit is ${Fahrenheit}</p>`
        }else if(scale == "F"||scale == "f"){
            let Celcius = Number((i-32)*5/9);
            document.getElementById("answer").innerHTML+=`
            <p>The conversation of Fahrenheit ${i} to Celcius is ${Celcius}</p>`
        }
    }
}