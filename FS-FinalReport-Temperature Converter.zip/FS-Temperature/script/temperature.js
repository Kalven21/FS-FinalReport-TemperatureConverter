function toCelToFa(){
    let temp = prompt("Choose Celcius or Fahrenheit:");
    if(temp == "C" || temp == "c"){
        let Celcius = Number(prompt("Enter temperature in Celcius:"));
        let Fahrenheit = Number((Celcius * 9/5) + 32);
        document.getElementById("answer").innerHTML+=`
        <p>The conversation of Celsius ${Celcius} to Fahrenheit is ${Fahrenheit}</p>
        `
    }else if(temp == "F" || temp == "f"){
        let Fahrenheit = Number(prompt("Enter temperature in Fahrenheit:"));
        let Celcius = Number((Fahrenheit-32)*5/9);
        document.getElementById("answer").innerHTML+=`
        <p>The conversation of Fahrenheit ${Fahrenheit} to Celcius is ${Celcius}</p>
        `
    }
}