console.log("Calculator");
//create a calculator that add up two numbers
let a=prompt("Enter a number");
let b=prompt("Enter a number");

let c = Number(a);
let d = Number(b);

let sum = c + d;
console.log("Sum: " + sum);